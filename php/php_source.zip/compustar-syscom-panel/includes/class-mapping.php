<?php
namespace CompuSyscom;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Mapeo Syscom ID Menu Nvl 3 -> categorías/subcategorías + márgenes/exclusión.
 * Opera sobre wp_compu_syscom_mapping (si existe).
 */
final class Mapping {
    public static function export_csv(): void {
        if (! current_user_can('manage_woocommerce')) { wp_die('Sin permisos.'); }
        check_admin_referer('compu_sys_mapping_export');
        global $wpdb;
        $table = $wpdb->prefix . 'compu_syscom_mapping';
        $rows = $wpdb->get_results("SELECT * FROM {$table} ORDER BY syscom_lvl3_id ASC", ARRAY_A);
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=compu_syscom_mapping.csv');
        $out = fopen('php://output', 'w');
        if ($rows) {
            fputcsv($out, array_keys($rows[0]));
            foreach ($rows as $r) { fputcsv($out, $r); }
        } else {
            fputcsv($out, ['syscom_lvl3_id','category_id','subcategory_id','margin_rule_id','is_excluded']);
        }
        fclose($out);
        exit;
    }

    public static function import_csv(): void {
        if (! current_user_can('manage_woocommerce')) { wp_die('Sin permisos.'); }
        check_admin_referer('compu_sys_mapping_import');
        if (empty($_FILES['mapping_csv']['tmp_name'])) {
            wp_safe_redirect( admin_url('admin.php?page=compu-syscom-mapping&msg=upload_missing') );
            exit;
        }
        $tmp = $_FILES['mapping_csv']['tmp_name'];
        $fh = fopen($tmp, 'r');
        if (!$fh) {
            wp_safe_redirect( admin_url('admin.php?page=compu-syscom-mapping&msg=upload_open_fail') );
            exit;
        }
        global $wpdb;
        $table = $wpdb->prefix . 'compu_syscom_mapping';
        $headers = fgetcsv($fh);
        $count = 0;
        if ($headers) {
            while(($row = fgetcsv($fh)) !== false) {
                $data = array_combine($headers, $row);
                // UPSERT simplificado
                $wpdb->replace($table, [
                    'syscom_lvl3_id' => intval($data['syscom_lvl3_id'] ?? 0),
                    'category_id'    => intval($data['category_id'] ?? 0),
                    'subcategory_id' => intval($data['subcategory_id'] ?? 0),
                    'margin_rule_id' => intval($data['margin_rule_id'] ?? 0),
                    'is_excluded'    => intval($data['is_excluded'] ?? 0),
                ]);
                $count++;
            }
        }
        fclose($fh);
        wp_safe_redirect( admin_url('admin.php?page=compu-syscom-mapping&msg=imported&n='.$count) );
        exit;
    }
}

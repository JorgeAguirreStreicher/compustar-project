<?php
namespace CompuSyscom;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Capa de UI de administrador: menús, páginas y assets.
 */
final class Syscom_Panel {
    public static function boot(): void {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_init', [Settings::class, 'register']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'assets']);

        // Acciones de admin-post (import/export mapping, descargar CSV, importar).
        add_action('admin_post_compu_sys_mapping_export', [Mapping::class, 'export_csv']);
        add_action('admin_post_compu_sys_mapping_import', [Mapping::class, 'import_csv']);
        add_action('admin_post_compu_sys_download_csv', [__CLASS__, 'handle_download_csv']);
        add_action('admin_post_compu_sys_import_csv', [__CLASS__, 'handle_import_csv']);
    }

    public static function assets($hook): void {
        // Cargar estilos/scripts sólo en nuestras pantallas (prefijo compu-syscom)
        if (strpos($hook, 'compu-syscom') === false) { return; }
        wp_enqueue_style('compu-syscom-admin', COMPU_SYS_PLUGIN_URL.'assets/admin.css', [], COMPU_SYS_VERSION);
        wp_enqueue_script('compu-syscom-admin', COMPU_SYS_PLUGIN_URL.'assets/admin.js', ['jquery'], COMPU_SYS_VERSION, true);
    }

    public static function menu(): void {
        // Menú raíz "Compustar"
        $cap = 'manage_woocommerce';
        add_menu_page('Compustar', 'Compustar', $cap, 'compustar', '__return_null', 'dashicons-screenoptions', 56);
        // Submenús del panel Syscom
        add_submenu_page('compustar', 'Syscom - Dashboard', 'Syscom: Dashboard', $cap, 'compu-syscom-dashboard', [__CLASS__, 'page_dashboard']);
        add_submenu_page('compustar', 'Syscom - Configuración', 'Syscom: Configuración', $cap, 'compu-syscom-settings', [__CLASS__, 'page_settings']);
        add_submenu_page('compustar', 'Syscom - Mapeo', 'Syscom: Mapeo', $cap, 'compu-syscom-mapping', [__CLASS__, 'page_mapping']);
        add_submenu_page('compustar', 'Syscom - Márgenes', 'Syscom: Márgenes', $cap, 'compu-syscom-margins', [__CLASS__, 'page_margins']);
        add_submenu_page('compustar', 'Syscom - Medios', 'Syscom: Medios', $cap, 'compu-syscom-media', [__CLASS__, 'page_media']);
        add_submenu_page('compustar', 'Syscom - Bitácoras', 'Syscom: Bitácoras', $cap, 'compu-syscom-logs', [__CLASS__, 'page_logs']);
    }

    public static function page_dashboard(): void { include COMPU_SYS_PLUGIN_DIR.'admin/views/page-dashboard.php'; }
    public static function page_settings(): void { include COMPU_SYS_PLUGIN_DIR.'admin/views/page-settings.php'; }
    public static function page_mapping(): void { include COMPU_SYS_PLUGIN_DIR.'admin/views/page-mapping.php'; }
    public static function page_margins(): void { include COMPU_SYS_PLUGIN_DIR.'admin/views/page-margins.php'; }
    public static function page_media(): void { include COMPU_SYS_PLUGIN_DIR.'admin/views/page-media.php'; }
    public static function page_logs(): void { include COMPU_SYS_PLUGIN_DIR.'admin/views/page-logs.php'; }

    // Handlers: descarga e importación manual
    public static function handle_download_csv(): void {
        if (! current_user_can('manage_woocommerce')) { wp_die('Sin permisos.'); }
        check_admin_referer('compu_sys_download_csv');
        $url = esc_url_raw($_POST['csv_url'] ?? '');
        if (!$url) {
            wp_safe_redirect( admin_url('admin.php?page=compu-syscom-dashboard&msg=no_url') );
            exit;
        }
        $r = Importer::download_csv($url);
        $q = $r['ok'] ? 'ok=1' : ('error='.rawurlencode($r['error'] ?? 'unknown'));
        wp_safe_redirect( admin_url('admin.php?page=compu-syscom-dashboard&'.$q) );
        exit;
    }
    public static function handle_import_csv(): void {
        if (! current_user_can('manage_woocommerce')) { wp_die('Sin permisos.'); }
        check_admin_referer('compu_sys_import_csv');
        $s = Helpers::get_settings();
        $path = trailingslashit($s['csv_storage_path']).'syscom.csv';
        $r = Importer::run($path);
        $q = $r['ok'] ? ('ok=1&summary='.rawurlencode(json_encode($r))) : ('error='.rawurlencode($r['error'] ?? 'unknown'));
        wp_safe_redirect( admin_url('admin.php?page=compu-syscom-dashboard&'.$q) );
        exit;
    }
}

<?php
namespace CompuSyscom;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Helpers generales y puros, fáciles de testear.
 */
final class Helpers {
    /**
     * Redondeo "comercial" al siguiente entero terminado en 0, 5 o 9 (sin centavos).
     * Ej.: 1234.10 -> 1235; 1236.00 -> 1240; 1291.00 -> 1295; 1296 -> 1299; 1299 -> 1299.
     */
    public static function round_0_5_9_up( float $amount ): int {
        $ceil = (int) ceil($amount); // fuera centavos
        $last = $ceil % 10;
        if (in_array($last, [0,5,9], true)) {
            return $ceil;
        }
        // Buscar siguiente 0/5/9
        for ($i = $ceil + 1; $i <= $ceil + 10; $i++) {
            $l = $i % 10;
            if (in_array($l, [0,5,9], true)) { return $i; }
        }
        return $ceil;
    }

    /**
     * Calcula precios netos y con IVA 8%/16% a partir de costo (USD) y tipo de cambio.
     * $rule = ['type' => 'PERCENT'|'FIXED', 'value' => float];
     * Retorna array con: net_mxn, gross_8, gross_16, rounded_8, rounded_16
     */
    public static function compute_prices(array $rule, float $cost_usd, float $tc): array {
        $base_mxn = $cost_usd * $tc;
        if (strtoupper($rule['type'] ?? '') === 'FIXED') {
            $net = max(0.0, $base_mxn + floatval($rule['value'] ?? 0));
        } else {
            $pct = floatval($rule['value'] ?? 0);
            $net = max(0.0, $base_mxn * (1.0 + $pct));
        }
        $gross_8 = $net * 1.08;
        $gross_16 = $net * 1.16;
        return [
            'net_mxn'   => $net,
            'gross_8'   => $gross_8,
            'gross_16'  => $gross_16,
            'rounded_8' => self::round_0_5_9_up($gross_8),
            'rounded_16'=> self::round_0_5_9_up($gross_16),
        ];
    }

    /** Sanitiza CSV de exclusiones: "1,2,3" -> [1,2,3] */
    public static function sanitize_id_list(string $raw): array {
        $parts = array_filter(array_map('trim', explode(',', $raw)));
        $ids = [];
        foreach ($parts as $p) {
            $n = intval($p);
            if ($n > 0) { $ids[] = $n; }
        }
        return array_values(array_unique($ids));
    }

    /** Retorna opción como array con defaults. */
    public static function get_settings(): array {
        $defaults = [
            'csv_storage_path'   => wp_normalize_path( WP_CONTENT_DIR . '/uploads/compustar_syscom' ),
            'timeout_seconds'    => 600,
            'max_memory_mb'      => 512,
            'stream_chunk_rows'  => 5000,
            'keep_only_latest'   => 1,
            'min_stock'          => 1,
            'exclude_lvl3_csv'   => '',
            'api_client_id'      => '',
            'api_client_secret'  => '',
            'api_base_url'       => 'https://api.syscom.mx',
            'http_headers_json'  => '',
            'rate_limit_rps'     => 1,
            'retry_policy_json'  => '{"retries":1,"sleep":2}',
            'cron_enabled'       => 0,
            'cron_hour_local'    => 3,
        ];
        $opt = get_option('compu_sys_settings', []);
        if (!is_array($opt)) { $opt = []; }
        return wp_parse_args($opt, $defaults);
    }
}

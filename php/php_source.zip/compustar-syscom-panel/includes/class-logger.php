<?php
namespace CompuSyscom;
use WP_Error;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Logger con doble salida: tablas propias (si existen) o error_log como respaldo.
 */
final class Logger {
    public static function log(string $level, string $message, array $context = []): void {
        $entry = sprintf('[COMPU_SYS] [%s] %s %s', strtoupper($level), $message, $context ? json_encode($context) : '');
        error_log($entry);
        // TODO: si existen wp_compu_import_logs / items, insertar filas aquí.
    }

    public static function info(string $m, array $c=[]): void { self::log('info', $m, $c); }
    public static function warn(string $m, array $c=[]): void { self::log('warning', $m, $c); }
    public static function err(string $m, array $c=[]): void { self::log('error', $m, $c); }
}

<?php
namespace CompuSyscom;
use WP_Error;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Importador CSV Syscom (streaming, >150MB).
 * Simplificado para entregar base funcional y segura: valida columnas, filtra existencias, mapea categorías/márgenes,
 * crea/actualiza producto y oferta (almacén 15) y registra logs.
 */
final class Importer {
    const WAREHOUSE_ID = 15; // Syscom
    const REQUIRED_COLS = ['Modelo','Marca','Titulo','Descripción','Su Precio','Existencias','ID Menu Nvl 3','Tipo de Cambio'];

    /** Descarga CSV desde URL y lo guarda en settings['csv_storage_path'] con nombre fijo syscom.csv */
    public static function download_csv(string $url): array {
        $s = Helpers::get_settings();
        $dir = $s['csv_storage_path'];
        if (! file_exists($dir)) {
            wp_mkdir_p($dir);
        }
        $dest = trailingslashit($dir) . 'syscom.csv';

        // Opcional: limpiar anteriores
        if (! empty($s['keep_only_latest'])) {
            foreach (glob(trailingslashit($dir).'*.csv') as $g) { @unlink($g); }
        }

        // Descargar con HTTP API (stream)
        $args = [
            'timeout' => max(60, intval($s['timeout_seconds'])),
            'stream'  => true,
            'filename'=> $dest,
        ];
        $resp = wp_safe_remote_get($url, $args);
        if (is_wp_error($resp)) {
            Logger::err('Error descargando CSV', ['err'=>$resp->get_error_message()]);
            return ['ok'=>false, 'error'=>$resp->get_error_message()];
        }
        $code = wp_remote_retrieve_response_code($resp);
        if ($code !== 200) {
            Logger::err('HTTP no 200 al descargar CSV', ['code'=>$code]);
            return ['ok'=>false, 'error'=>"HTTP $code"];
        }
        Logger::info('CSV descargado', ['dest'=>$dest]);
        return ['ok'=>true, 'path'=>$dest];
    }

    /** Corrida principal de importación */
    public static function run(string $csv_path): array {
        if (! file_exists($csv_path)) {
            return ['ok'=>false,'error'=>'CSV no encontrado'];
        }
        $s = Helpers::get_settings();
        $min_stock = intval($s['min_stock']);
        $exclude_lvl3 = Helpers::sanitize_id_list($s['exclude_lvl3_csv']);

        $file = new \SplFileObject($csv_path, 'r');
        $file->setFlags(\SplFileObject::READ_CSV | \SplFileObject::SKIP_EMPTY);
        $file->setCsvControl(','); // Ajustar si el CSV usa otro delimitador
        $headers = $file->fgetcsv();
        if (!is_array($headers)) { return ['ok'=>false,'error'=>'Encabezados inválidos']; }

        // Validación de columnas mínimas
        foreach (self::REQUIRED_COLS as $req) {
            if (array_search($req, $headers, true) === false) {
                return ['ok'=>false,'error'=>"Falta columna requerida: {$req}"];
            }
        }
        $idx = array_flip($headers);

        $processed = 0; $created = 0; $updated = 0; $skipped = 0; $errors = 0;
        while (! $file->eof()) {
            $row = $file->fgetcsv();
            if (!is_array($row) || count($row) < count($headers)) { continue; }

            $modelo   = trim((string)($row[$idx['Modelo']] ?? ''));
            if ($modelo === '') { $skipped++; continue; } // SKU vacío
            $marca    = trim((string)($row[$idx['Marca']] ?? ''));
            $titulo   = trim((string)($row[$idx['Titulo']] ?? ''));
            $desc     = (string)($row[$idx['Descripción']] ?? '');
            $precio   = floatval($row[$idx['Su Precio']] ?? 0);
            $stock    = intval($row[$idx['Existencias']] ?? 0);
            $lvl3     = intval($row[$idx['ID Menu Nvl 3']] ?? 0);
            $tc       = floatval($row[$idx['Tipo de Cambio']] ?? 0);
            $weight   = isset($idx['Peso Kg']) ? floatval($row[$idx['Peso Kg']]) : 0.0;
            $upc      = isset($idx['UPC/EAN']) ? trim((string)$row[$idx['UPC/EAN']]) : '';

            if ($stock < $min_stock) { $skipped++; continue; }
            if (in_array($lvl3, $exclude_lvl3, true)) { $skipped++; continue; }

            // Resolver categoría/subcategoría + margen desde mapeo
            $map = self::get_mapping($lvl3);
            if ($map && intval($map['is_excluded']) === 1) { $skipped++; continue; }
            $margin_rule = self::get_margin_rule(intval($map['margin_rule_id'] ?? 0));

            // 1) Asegurar marca como término de product_brand
            $brand_term_id = self::ensure_brand($marca);

            // 2) Crear/actualizar producto (nativo)
            $title = trim($marca.' '.$modelo.' '.$titulo);
            $post_id = self::upsert_product($modelo, $title, $desc, $weight, $upc, $brand_term_id, $map);

            // 3) Insertar/actualizar oferta (propia) para almacén 15
            $offer_ok = self::upsert_offer($post_id, $precio, $stock, $tc, $margin_rule);

            if ($post_id && $offer_ok) {
                $processed++;
            } else {
                $errors++;
            }
        }

        $summary = compact('processed','created','updated','skipped','errors');
        Logger::info('Importación finalizada', $summary);
        return ['ok'=>true] + $summary;
    }

    private static function ensure_brand(string $brand): int {
        if ($brand === '') { return 0; }
        $term = term_exists($brand, 'product_brand');
        if ($term === 0 || $term === null) {
            $term = wp_insert_term($brand, 'product_brand');
        }
        if (is_wp_error($term)) { return 0; }
        return intval(is_array($term) ? ($term['term_id'] ?? 0) : ($term->term_id ?? 0));
    }

    private static function upsert_product(string $sku, string $title, string $content, float $weight, string $upc, int $brand_term_id, ?array $map): int {
        // Buscar por _sku
        global $wpdb;
        $post_id = wc_get_product_id_by_sku($sku);
        $is_new = false;
        if (! $post_id) {
            // Crear producto
            $post_id = wp_insert_post([
                'post_title'   => $title,
                'post_content' => $content,
                'post_excerpt' => $title,
                'post_status'  => 'publish',
                'post_type'    => 'product',
            ], true);
            if (is_wp_error($post_id)) {
                Logger::err('No se pudo crear producto', ['sku'=>$sku, 'err'=>$post_id->get_error_message()]);
                return 0;
            }
            $is_new = true;
            update_post_meta($post_id, '_sku', $sku);
        } else {
            // Actualizar título/desc para mantener canon
            wp_update_post([
                'ID'           => $post_id,
                'post_title'   => $title,
                'post_content' => $content,
                'post_excerpt' => $title,
            ]);
        }

        // Meta nativo
        if ($weight > 0) { update_post_meta($post_id, '_weight', $weight); }
        if ($upc !== '') { update_post_meta($post_id, '_global_unique_id', $upc); }

        // Taxonomías
        if ($brand_term_id > 0) {
            wp_set_object_terms($post_id, [$brand_term_id], 'product_brand', false);
        }
        if ($map) {
            $cats = [];
            if (!empty($map['category_id'])) { $cats[] = intval($map['category_id']); }
            if (!empty($map['subcategory_id'])) { $cats[] = intval($map['subcategory_id']); }
            if ($cats) { wp_set_object_terms($post_id, $cats, 'product_cat', false); }
        }

        // TODO: imágenes y galería (si CSV trae URLs)

        // Reflejo en tabla propia wp_compu_products (mínimo SKU + nombre)
        $table = $wpdb->prefix . 'compu_products';
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) === $table) {
            $wpdb->replace($table, [
                'product_id'        => $post_id,
                'sku'               => $sku,
                'name'              => $title,
                'short_description' => $title,
                'long_description'  => $content,
                'upc_ean'           => $upc,
                'images_json'       => json_encode([]),
                'documents_json'    => json_encode([]),
            ]);
        }

        return $post_id;
    }

    private static function upsert_offer(int $post_id, float $cost_usd, int $stock, float $tc, ?array $margin_rule): bool {
        if ($post_id <= 0) { return false; }
        global $wpdb;
        $table = $wpdb->prefix . 'compu_offers';
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) !== $table) {
            // Tabla no existe: no fallar duro
            Logger::warn('Tabla compu_offers no existe, omitiendo oferta', ['product_id'=>$post_id]);
            return true;
        }
        $rule = $margin_rule ?: ['type'=>'PERCENT','value'=>0.10];
        $calc = Helpers::compute_prices($rule, $cost_usd, max(1.0,$tc));
        // UPSERT por product_id + warehouse_id
        $wpdb->replace($table, [
            'product_id'    => $post_id,
            'warehouse_id'  => self::WAREHOUSE_ID,
            'cost_base'     => $cost_usd,
            'exchange_rate' => $tc,
            'stock'         => max(0,$stock),
            'margin_type'   => strtoupper($rule['type']),
            'margin_value'  => floatval($rule['value']),
            'net_mxn'       => $calc['net_mxn'],
            'gross_8'       => $calc['gross_8'],
            'gross_16'      => $calc['gross_16'],
            'rounded_8'     => $calc['rounded_8'],
            'rounded_16'    => $calc['rounded_16'],
            'updated_at'    => current_time('mysql'),
        ]);
        return true;
    }

    private static function get_mapping(int $lvl3): ?array {
        if ($lvl3 <= 0) { return null; }
        global $wpdb;
        $table = $wpdb->prefix . 'compu_syscom_mapping';
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) !== $table) { return null; }
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE syscom_lvl3_id = %d", $lvl3), ARRAY_A);
        return $row ?: null;
    }

    private static function get_margin_rule(int $rule_id): ?array {
        if ($rule_id <= 0) { return null; }
        global $wpdb;
        $table = $wpdb->prefix . 'compu_margin_rules';
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) !== $table) { return null; }
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE margin_rule_id = %d", $rule_id), ARRAY_A);
        if (!$row) { return null; }
        return ['type'=>$row['type'] ?? 'PERCENT', 'value'=>floatval($row['value'] ?? 0)];
    }
}

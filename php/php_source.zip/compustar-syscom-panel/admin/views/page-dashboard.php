<div class="wrap">
  <h1>Syscom — Dashboard</h1>
  <?php if (isset($_GET['ok'])): ?>
    <div class="notice notice-success"><p>Operación completada correctamente.</p></div>
  <?php elseif (isset($_GET['error'])): ?>
    <div class="notice notice-error"><p>Error: <?php echo esc_html($_GET['error']); ?></p></div>
  <?php endif; ?>

  <div class="card">
    <h2>Descarga / Importación manual</h2>
    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
      <?php wp_nonce_field('compu_sys_download_csv'); ?>
      <input type="hidden" name="action" value="compu_sys_download_csv">
      <p><label>URL CSV Syscom:
        <input type="url" name="csv_url" class="regular-text" placeholder="https://..." required>
      </label></p>
      <p><button class="button button-primary">Descargar CSV</button></p>
    </form>
    <hr/>
    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
      <?php wp_nonce_field('compu_sys_import_csv'); ?>
      <input type="hidden" name="action" value="compu_sys_import_csv">
      <p><button class="button button-primary">Importar CSV (último descargado)</button></p>
    </form>
  </div>

  <div class="card">
    <h2>Resumen</h2>
    <p>Este panel ejecuta el flujo end‑to‑end: descarga CSV &gt; validación &gt; mapeo &gt; creación/actualización de producto &gt; oferta en Almacén 15.</p>
    <p>Logs detallados en PHP error_log y, si existen, en tablas <code>wp_compu_import_runs</code>/<code>wp_compu_import_logs</code>.</p>
  </div>
</div>

<div class="wrap">
  <h1>Syscom — Medios por SKU</h1>
  <p>Vista simple de imágenes/documentos guardados en <code>wp_compu_products</code>. (Implementación básica).</p>
  <form method="get">
    <input type="hidden" name="page" value="compu-syscom-media">
    <p><label>SKU (Modelo): <input type="text" name="sku" value="<?php echo esc_attr($_GET['sku'] ?? ''); ?>"></label>
    <button class="button">Buscar</button></p>
  </form>
  <?php
  if (!empty($_GET['sku'])) {
    global $wpdb;
    $table = $wpdb->prefix.'compu_products';
    $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE sku=%s", sanitize_text_field($_GET['sku'])), ARRAY_A);
    if ($row) {
      echo '<h2>Resultado</h2>';
      echo '<pre>'.esc_html(json_encode([
        'images'=>json_decode($row['images_json'] ?? '[]', true),
        'documents'=>json_decode($row['documents_json'] ?? '[]', true),
      ], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)).'</pre>';
    } else {
      echo '<div class="notice notice-warning"><p>No se encontró el SKU en compu_products.</p></div>';
    }
  }
  ?>
</div>

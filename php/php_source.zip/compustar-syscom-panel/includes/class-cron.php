<?php
namespace CompuSyscom;
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Cron {
    const HOOK = 'compu_sys_daily_import';

    public static function schedule_if_needed(?array $settings = null): void {
        $s = $settings ?: Helpers::get_settings();
        self::clear(); // reset por simplicidad
        if (empty($s['cron_enabled'])) { return; }
        // Programar a la hora local indicada (min 0)
        $hour = min(23, max(0, intval($s['cron_hour_local'])));
        $ts = strtotime( sprintf('today %02d:00:00', $hour), current_time('timestamp') );
        if ($ts <= current_time('timestamp')) { $ts = strtotime('+1 day', $ts); }
        wp_schedule_event($ts, 'daily', self::HOOK);
    }

    public static function clear(): void {
        $ts = wp_next_scheduled(self::HOOK);
        if ($ts) { wp_unschedule_event($ts, self::HOOK); }
    }
}

// Handler del cron: descarga e importa (si hay URL configurada en headers JSON o settings personalizados).
add_action( Cron::HOOK, function(){
    $s = Helpers::get_settings();
    // En este ejemplo, asumimos que el admin pegará la URL del CSV en el campo http_headers_json como {"csv_url":"https://..."}
    $headers = json_decode($s['http_headers_json'] ?: '{}', true);
    $csv_url = is_array($headers) ? ($headers['csv_url'] ?? '') : '';
    if ($csv_url) {
        $d = Importer::download_csv($csv_url);
        if (!empty($d['ok'])) {
            Importer::run($d['path']);
        } else {
            Logger::err('Cron: no se pudo descargar CSV', ['error'=>$d['error'] ?? '']);
        }
    } else {
        Logger::warn('Cron: csv_url no configurado en HTTP Headers JSON');
    }
});

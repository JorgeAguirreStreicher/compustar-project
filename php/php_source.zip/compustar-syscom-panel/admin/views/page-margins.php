<div class="wrap">
  <h1>Syscom — Márgenes y Redondeo</h1>
  <p>Las reglas se leen de <code>wp_compu_margin_rules</code> (si existe). Cada mapeo de subcategoría referencia un <code>margin_rule_id</code>.</p>
  <p>Tipos soportados: <code>PERCENT</code> (valor en decimal, p.ej. 0.25 = 25%) y <code>FIXED</code> (valor en MXN).</p>
  <p>El redondeo 0/5/9 se aplica al precio con IVA 8% o 16% al momento de mostrar.</p>
</div>

<div class="wrap">
  <h1>Syscom — Configuración</h1>
  <form method="post" action="options.php">
    <?php
      settings_fields('compu_sys_settings_group');
      do_settings_sections('compu_sys_settings');
      submit_button();
    ?>
  </form>
  <p class="description">Consejo: En "HTTP Headers (JSON)" puedes colocar <code>{"csv_url":"https://..."}</code> para que el cron utilice esa URL.</p>
</div>

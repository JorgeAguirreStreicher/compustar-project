<?php
/**
 * Plugin Name: Compustar — Panel de Control Syscom (Almacén 15)
 * Description: Panel de control para importar el CSV masivo de Syscom (>150 MB), mapear categorías, aplicar márgenes/IVA/redondeo, y publicar en WooCommerce. Incluye Dashboard, Configuración, Mapeo, Márgenes, Medios y Bitácoras.
 * Version: 1.2.0
 * Author: Compustar + Leo (ChatGPT)
 * Text Domain: compu-syscom
 * Domain Path: /languages
 *
 * NOTAS DE DISEÑO (resumen):
 * - SKU canónico = Modelo (Syscom), almacenado en _sku y también en tabla propia wp_compu_products.
 * - Marca en taxonomía nativa product_brand (fuente de verdad).
 * - UPC/EAN en meta nativo _global_unique_id.
 * - Precios/stock SOLO en tabla propia wp_compu_offers (USD + tipo de cambio), con IVA cacheado 8%/16% y redondeo 0/5/9.
 * - Selector de almacén en PDP (Syscom = Almacén 15). Carrito fija almacén elegido por línea.
 *
 * Requisitos mínimos:
 * - WordPress 6.0+ / WooCommerce 7.0+
 * - PHP 8.0+
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// -------------------------------------------------------------------------
// Constantes del plugin (prefijo COMPU_SYS_* para este módulo).
// -------------------------------------------------------------------------
define( 'COMPU_SYS_VERSION', '1.2.0' );
define( 'COMPU_SYS_PLUGIN_FILE', __FILE__ );
define( 'COMPU_SYS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'COMPU_SYS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Cargar dependencias del núcleo del plugin.
require_once COMPU_SYS_PLUGIN_DIR . 'includes/helpers.php';
require_once COMPU_SYS_PLUGIN_DIR . 'includes/class-logger.php';
require_once COMPU_SYS_PLUGIN_DIR . 'includes/class-settings.php';
require_once COMPU_SYS_PLUGIN_DIR . 'includes/class-mapping.php';
require_once COMPU_SYS_PLUGIN_DIR . 'includes/class-importer.php';
require_once COMPU_SYS_PLUGIN_DIR . 'includes/class-cron.php';
require_once COMPU_SYS_PLUGIN_DIR . 'includes/class-syscom-panel.php';

// -------------------------------------------------------------------------
// Activación / Desactivación: verificaciones básicas y cron.
// -------------------------------------------------------------------------
register_activation_hook( __FILE__, function() {
    // Chequeo rápido de WooCommerce.
    if ( ! class_exists( 'WooCommerce' ) ) {
        deactivate_plugins( plugin_basename( __FILE__ ) );
        wp_die( 'Este plugin requiere WooCommerce activo.' );
    }

    // Preparar evento de cron si está habilitado en settings (se revalida en runtime).
    \CompuSyscom\Cron::schedule_if_needed();
});

register_deactivation_hook( __FILE__, function() {
    \CompuSyscom\Cron::clear();
});

// -------------------------------------------------------------------------
// Inicializar el panel.
// -------------------------------------------------------------------------
add_action( 'plugins_loaded', function() {
    load_plugin_textdomain( 'compu-syscom', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
    // Boot del panel (admin).
    if ( is_admin() ) {
        \CompuSyscom\Syscom_Panel::boot();
    }
});

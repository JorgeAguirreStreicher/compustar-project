=== Compustar — Panel de Control Syscom (Almacén 15) ===
Version: 1.2.0
Requires at least: 6.0
Tested up to: 2025-08-30
Requires PHP: 8.0
License: GPLv2 or later

Este plugin implementa un panel de control para la importación masiva del CSV de Syscom, mapeo de categorías,
márgenes con redondeo (0/5/9), y publicación de productos en WooCommerce con precios/stock en tablas propias.

Páginas:
- Dashboard: descarga/importación manual, resumen.
- Configuración: CSV, filtros, API, cron.
- Mapeo: import/export CSV de relaciones ID Menu Nvl 3.
- Márgenes: documentación del comportamiento.
- Medios: visor simple por SKU.
- Bitácoras: guía para revisar logs.

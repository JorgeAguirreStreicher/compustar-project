<div class="wrap">
  <h1>Syscom — Bitácoras</h1>
  <p>Por ahora los mensajes se envían a <code>error_log</code> del servidor. Si existen tablas <code>wp_compu_import_runs</code>/<code>wp_compu_import_logs</code>, se pueden extender aquí.</p>
  <p>Recomendación: habilita <code>WP_DEBUG_LOG</code> en <code>wp-config.php</code> para revisar <code>wp-content/debug.log</code>.</p>
</div>

<div class="wrap">
  <h1>Syscom — Mapeo de categorías (ID Menu Nvl 3)</h1>
  <p>Administra la relación <code>syscom_lvl3_id</code> → <code>category_id</code>/<code>subcategory_id</code> + <code>margin_rule_id</code> + <code>is_excluded</code>.</p>
  <div class="card">
    <h2>Exportar</h2>
    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
      <?php wp_nonce_field('compu_sys_mapping_export'); ?>
      <input type="hidden" name="action" value="compu_sys_mapping_export">
      <button class="button">Descargar CSV</button>
    </form>
  </div>
  <div class="card">
    <h2>Importar</h2>
    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" enctype="multipart/form-data">
      <?php wp_nonce_field('compu_sys_mapping_import'); ?>
      <input type="hidden" name="action" value="compu_sys_mapping_import">
      <input type="file" name="mapping_csv" accept=".csv" required>
      <button class="button button-primary">Subir CSV</button>
    </form>
  </div>
  <p class="description">Las columnas esperadas son: <code>syscom_lvl3_id,category_id,subcategory_id,margin_rule_id,is_excluded</code>.</p>
</div>

<?php
namespace CompuSyscom;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Admin Settings: registra ajustes y renderiza la página de Configuración.
 */
final class Settings {
    public static function register(): void {
        // Registrar opción principal.
        register_setting('compu_sys_settings_group', 'compu_sys_settings', [
            'type' => 'array',
            'sanitize_callback' => [__CLASS__, 'sanitize'],
            'default' => Helpers::get_settings(),
        ]);

        // Secciones
        add_settings_section('compu_sys_sec_csv', 'CSV y Performance', function(){ echo '<p>Descarga/lectura de CSV masivo (&gt;150 MB).</p>'; }, 'compu_sys_settings');
        add_settings_section('compu_sys_sec_filters', 'Filtros y Exclusiones', function(){ echo '<p>Existencias mínimas y exclusión por ID Menu Nvl 3.</p>'; }, 'compu_sys_settings');
        add_settings_section('compu_sys_sec_api', 'API Syscom', function(){ echo '<p>Credenciales y límites de API.</p>'; }, 'compu_sys_settings');
        add_settings_section('compu_sys_sec_cron', 'Cron', function(){ echo '<p>Programa una corrida diaria automática.</p>'; }, 'compu_sys_settings');

        // Campos - CSV y performance
        add_settings_field('csv_storage_path', 'Ruta de almacenamiento CSV', [__CLASS__, 'field_text'], 'compu_sys_settings', 'compu_sys_sec_csv', ['key'=>'csv_storage_path', 'desc'=>'Directorio local donde se guardará el CSV.']);
        add_settings_field('timeout_seconds', 'Timeout (s)', [__CLASS__, 'field_number'], 'compu_sys_settings', 'compu_sys_sec_csv', ['key'=>'timeout_seconds']);
        add_settings_field('max_memory_mb', 'Límite de memoria (MB)', [__CLASS__, 'field_number'], 'compu_sys_settings', 'compu_sys_sec_csv', ['key'=>'max_memory_mb']);
        add_settings_field('stream_chunk_rows', 'Filas por chunk (stream)', [__CLASS__, 'field_number'], 'compu_sys_settings', 'compu_sys_sec_csv', ['key'=>'stream_chunk_rows']);
        add_settings_field('keep_only_latest', 'Conservar solo el último CSV', [__CLASS__, 'field_checkbox'], 'compu_sys_settings', 'compu_sys_sec_csv', ['key'=>'keep_only_latest']);

        // Filtros
        add_settings_field('min_stock', 'Existencias mínimas', [__CLASS__, 'field_number'], 'compu_sys_settings', 'compu_sys_sec_filters', ['key'=>'min_stock']);
        add_settings_field('exclude_lvl3_csv', 'Excluir ID Menu Nvl 3 (separados por coma)', [__CLASS__, 'field_text'], 'compu_sys_settings', 'compu_sys_sec_filters', ['key'=>'exclude_lvl3_csv']);

        // API
        add_settings_field('api_client_id', 'Id de cliente', [__CLASS__, 'field_text'], 'compu_sys_settings', 'compu_sys_sec_api', ['key'=>'api_client_id']);
        add_settings_field('api_client_secret', 'Secreto de cliente', [__CLASS__, 'field_password'], 'compu_sys_settings', 'compu_sys_sec_api', ['key'=>'api_client_secret']);
        add_settings_field('api_base_url', 'Base URL API', [__CLASS__, 'field_text'], 'compu_sys_settings', 'compu_sys_sec_api', ['key'=>'api_base_url']);
        add_settings_field('http_headers_json', 'HTTP Headers (JSON)', [__CLASS__, 'field_textarea'], 'compu_sys_settings', 'compu_sys_sec_api', ['key'=>'http_headers_json']);
        add_settings_field('rate_limit_rps', 'Rate limit (requests/seg)', [__CLASS__, 'field_number'], 'compu_sys_settings', 'compu_sys_sec_api', ['key'=>'rate_limit_rps']);
        add_settings_field('retry_policy_json', 'Retry policy (JSON)', [__CLASS__, 'field_text'], 'compu_sys_settings', 'compu_sys_sec_api', ['key'=>'retry_policy_json']);

        // Cron
        add_settings_field('cron_enabled', 'Habilitar cron diario', [__CLASS__, 'field_checkbox'], 'compu_sys_settings', 'compu_sys_sec_cron', ['key'=>'cron_enabled']);
        add_settings_field('cron_hour_local', 'Hora local (0-23)', [__CLASS__, 'field_number'], 'compu_sys_settings', 'compu_sys_sec_cron', ['key'=>'cron_hour_local']);
    }

    public static function sanitize($input) {
        $s = Helpers::get_settings();
        $s['csv_storage_path']  = wp_normalize_path( sanitize_text_field( $input['csv_storage_path'] ?? $s['csv_storage_path'] ) );
        $s['timeout_seconds']   = max(60, intval( $input['timeout_seconds'] ?? $s['timeout_seconds'] ));
        $s['max_memory_mb']     = max(128, intval( $input['max_memory_mb'] ?? $s['max_memory_mb'] ));
        $s['stream_chunk_rows'] = max(1000, intval( $input['stream_chunk_rows'] ?? $s['stream_chunk_rows'] ));
        $s['keep_only_latest']  = ! empty( $input['keep_only_latest'] ) ? 1 : 0;

        $s['min_stock']         = max(0, intval( $input['min_stock'] ?? $s['min_stock'] ));
        $s['exclude_lvl3_csv']  = sanitize_text_field( $input['exclude_lvl3_csv'] ?? '' );

        $s['api_client_id']     = sanitize_text_field( $input['api_client_id'] ?? '' );
        $s['api_client_secret'] = sanitize_text_field( $input['api_client_secret'] ?? '' );
        $s['api_base_url']      = esc_url_raw( $input['api_base_url'] ?? $s['api_base_url'] );
        $s['http_headers_json'] = wp_kses_post( $input['http_headers_json'] ?? '' );
        $s['rate_limit_rps']    = max(1, intval( $input['rate_limit_rps'] ?? $s['rate_limit_rps'] ));
        $s['retry_policy_json'] = wp_kses_post( $input['retry_policy_json'] ?? $s['retry_policy_json'] );

        $s['cron_enabled']      = ! empty( $input['cron_enabled'] ) ? 1 : 0;
        $s['cron_hour_local']   = min(23, max(0, intval( $input['cron_hour_local'] ?? $s['cron_hour_local'] )));

        // Re-schedule cron si cambió.
        Cron::schedule_if_needed($s);
        return $s;
    }

    // ------------------ Render de campos ------------------
    public static function field_text($args){ self::render_input('text', $args); }
    public static function field_password($args){ self::render_input('password', $args); }
    public static function field_number($args){ self::render_input('number', $args); }
    public static function field_checkbox($args){ self::render_input('checkbox', $args); }
    public static function field_textarea($args){ self::render_textarea($args); }

    private static function render_input($type, $args){
        $opt = Helpers::get_settings();
        $key = esc_attr($args['key']);
        $val = $opt[$key] ?? '';
        if ($type === 'checkbox') {
            printf('<input type="checkbox" name="compu_sys_settings[%1$s]" value="1" %2$s/>', $key, checked(1, $val, false));
        } else {
            printf('<input type="%1$s" class="regular-text" name="compu_sys_settings[%2$s]" value="%3$s"/>', esc_attr($type), $key, esc_attr($val));
        }
        if (!empty($args['desc'])) {
            echo '<p class="description">'.esc_html($args['desc']).'</p>';
        }
    }
    private static function render_textarea($args){
        $opt = Helpers::get_settings();
        $key = esc_attr($args['key']);
        $val = $opt[$key] ?? '';
        printf('<textarea class="large-text code" rows="5" name="compu_sys_settings[%1$s]">%2$s</textarea>', $key, esc_textarea($val));
        if (!empty($args['desc'])) {
            echo '<p class="description">'.esc_html($args['desc']).'</p>';
        }
    }
}

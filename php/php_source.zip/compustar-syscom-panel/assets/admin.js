// JS admin futuro
